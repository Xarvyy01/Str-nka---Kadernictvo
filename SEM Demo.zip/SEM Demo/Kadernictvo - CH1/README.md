# Branch
Momentálne je otvorená branch __MAIN__, ktorá obsahuje štartér pre zadanie. _Výsledok_ obsahuje branch  __SOLUTION__.

# Cvičenie 01

Súbor `index.html` obsahuje nevalídny __HTML 5__ dokument. S pomocou [validátora W3C](https://validator.w3.org/#validate_by_input) zistite kde sú chyby a upravte ho tak, aby bol valídny.

## Ako nájsť branch môjho cvičenia?
Pokiaľ sa chcete dostať k riešeniu z cvičenia je potrebné otvoriť si príslušnú _branch_, ktorej názov sa skladá:

__MIESTNOST__ + "-" + __HODINA ZAČIATKU__ + "-" + __DEN__

Ak teda navštevujete cvičenie pondelok o 08:00 v RA323, tak sa branch bude volať: __RA323-08-PON__